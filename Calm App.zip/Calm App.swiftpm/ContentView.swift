import SwiftUI
import AVFoundation

var player: AVAudioPlayer?

struct Bubble: Identifiable {
    let id = UUID()
    var x: CGFloat
    var y: CGFloat
    var size: CGFloat
}

struct ContentView: View {
    @State private var bubbles: [Bubble] = []
    @State private var currentColor = Color(.systemTeal)
    let colors: [Color] = [.teal, .blue, .purple, .pink, .mint]
    @State private var colorIndex = 0
    
    let bubbleCount = 12
    let screenHeight: CGFloat = 800
    let screenWidth: CGFloat = 400
    
    var body: some View {
        ZStack {
            // 🌈 Background that changes color smoothly
            currentColor
                .ignoresSafeArea()
                .animation(.easeInOut(duration: 5), value: currentColor)
            
            // Floating bubbles
            ForEach(bubbles) { bubble in
                Circle()
                    .fill(Color.white.opacity(0.3))
                    .frame(width: bubble.size, height: bubble.size)
                    .position(x: bubble.x, y: bubble.y)
            }
            
            VStack(spacing: 25) {
                Text("Calm Sensory Sounds 🌸")
                    .font(.largeTitle)
                    .foregroundColor(.white)
                    .padding(.top, 50)
                
                Button("Play Ocean Waves 🌊") {
                    playSound(named: "ocean")
                }
                .buttonStyle(SensoryButton())
                
                Button("Play Rain ☔️") {
                    playSound(named: "rain")
                }
                .buttonStyle(SensoryButton())
                
                Button("Play Wind 🌬️") {
                    playSound(named: "wind")
                }
                .buttonStyle(SensoryButton())
            }
        }
        .onAppear {
            // Create floating bubbles
            for _ in 0..<bubbleCount {
                let bubble = Bubble(
                    x: CGFloat.random(in: 50...screenWidth - 50),
                    y: CGFloat.random(in: 0...screenHeight),
                    size: CGFloat.random(in: 20...60)
                )
                bubbles.append(bubble)
            }
            
            // Animate bubbles
            Timer.scheduledTimer(withTimeInterval: 0.03, repeats: true) { _ in
                for i in bubbles.indices {
                    bubbles[i].y -= 0.5
                    bubbles[i].x += CGFloat.random(in: -0.3...0.3)
                    
                    if bubbles[i].y < -50 {
                        bubbles[i].y = screenHeight
                        bubbles[i].x = CGFloat.random(in: 50...screenWidth - 50)
                    }
                }
            }
            
            // 🌈 Slowly cycle colors every few seconds
            Timer.scheduledTimer(withTimeInterval: 5, repeats: true) { _ in
                colorIndex = (colorIndex + 1) % colors.count
                currentColor = colors[colorIndex]
            }
        }
    }
    
    func playSound(named soundName: String) {
        if let path = Bundle.main.path(forResource: soundName, ofType: "mp3") {
            let url = URL(fileURLWithPath: path)
            player = try? AVAudioPlayer(contentsOf: url)
            player?.play()
        } else {
            print("Sound not found: \(soundName)")
        }
    }
}

struct SensoryButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.title2)
            .padding()
            .frame(maxWidth: 280)
            .background(Color.white.opacity(configuration.isPressed ? 0.5 : 0.3))
            .cornerRadius(20)
            .foregroundColor(.white)
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
            .animation(.easeOut(duration: 0.2), value: configuration.isPressed)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
